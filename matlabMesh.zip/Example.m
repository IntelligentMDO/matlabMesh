
clear all;
clc;

Main_CFD('K:\matlabMesh',1);